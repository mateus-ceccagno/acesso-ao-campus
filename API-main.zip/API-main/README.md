# API

## Requisitos
Para utilizar a API, é necessário ter o python e pip instalados.

## Instalação
Crie um ambiente virtual com o comando:

* python -m venv env

Ative-o com o comando:

* .\env\Scripts\activate

Crie um arquivo .env como o .envexemple


As bibliotecas externas estão listadas em requirements.txt, para instalar use o comando:

* python -m pip install -r requirements.txt

Após inicialise o servidor com o comando:

* flask run --host=xxx.xxx.xxx.xxx(IP)
